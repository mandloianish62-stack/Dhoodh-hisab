const B = import.meta.env.VITE_API || 'http://localhost:5000';
export const api = async (p, m = 'GET', b) => {
  const r = await fetch(B + '/api' + p, { method: m, headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + (localStorage.token || '') }, body: b && JSON.stringify(b) });
  if (r.status === 401 && p !== '/login') { localStorage.removeItem('token'); location.reload(); }
  return r.json();
};
