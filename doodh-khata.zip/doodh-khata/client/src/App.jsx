import { useState, useEffect } from 'react';
import { api } from './api';
const today = () => new Date().toISOString().slice(0, 10);
const rs = n => '₹' + Math.round(n || 0);
const TABS = ['Grahak', 'Doodh', 'Saaman', 'Jama', 'Hisab', 'Settings'];

function Login({ ok }) {
  const [f, setF] = useState({ user: '', pass: '' }), [err, setErr] = useState('');
  const go = async () => { const r = await api('/login', 'POST', f); if (r.token) { localStorage.token = r.token; ok(); } else setErr(r.error); };
  return <div className="app"><h2>Doodh Khata</h2>
    <input placeholder="User" value={f.user} onChange={e => setF({ ...f, user: e.target.value })} />
    <input type="password" placeholder="Password" value={f.pass} onChange={e => setF({ ...f, pass: e.target.value })} />
    {err && <p className="due">{err}</p>}<button className="go" onClick={go}>Login</button></div>;
}

const CustSel = ({ cs, v, on }) => <select value={v} onChange={e => on(e.target.value)}>
  <option value="">Grahak chuno</option>{cs.map(c => <option key={c._id} value={c._id}>{c.name} {c.phone || ''}</option>)}</select>;
const nameOf = (cs, id) => cs.find(c => c._id === id)?.name || '?';

function Customers({ cs, load }) {
  const [f, setF] = useState({ name: '', phone: '', address: '' }), [q, setQ] = useState('');
  const add = async () => { if (!f.name) return; await api('/customers', 'POST', f); setF({ name: '', phone: '', address: '' }); load(); };
  const del = async c => { if (confirm(c.name + ' hatana hai?')) { await api('/customers/' + c._id, 'DELETE'); load(); } };
  const list = cs.filter(c => (c.name + (c.phone || '')).toLowerCase().includes(q.toLowerCase()));
  return <div>
    <input placeholder="Naam" value={f.name} onChange={e => setF({ ...f, name: e.target.value })} />
    <input placeholder="Mobile" inputMode="numeric" value={f.phone} onChange={e => setF({ ...f, phone: e.target.value })} />
    <input placeholder="Address (optional)" value={f.address} onChange={e => setF({ ...f, address: e.target.value })} />
    <button className="go" onClick={add}>Grahak jodo</button>
    <input placeholder="Naam ya number se khojo" value={q} onChange={e => setQ(e.target.value)} />
    {list.map(c => <div className="item" key={c._id}><span>{c.name}<small>{c.phone} {c.address}</small></span><button className="x" onClick={() => del(c)}>Hatao</button></div>)}
  </div>;
}

function Milk({ cs, rate }) {
  const [f, setF] = useState({ customer: '', date: today(), shift: 'subah', litre: '', rate: '' }), [rows, setRows] = useState([]);
  const get = async () => setRows(await api('/milk?date=' + f.date));
  useEffect(() => { get(); }, [f.date]);
  const save = async () => { if (!f.customer || !f.litre) return; await api('/milk', 'POST', { ...f, rate: f.rate || rate }); setF({ ...f, litre: '', rate: '' }); get(); };
  const del = async id => { await api('/milk/' + id, 'DELETE'); get(); };
  return <div>
    <CustSel cs={cs} v={f.customer} on={v => setF({ ...f, customer: v })} />
    <div className="row"><input type="date" value={f.date} onChange={e => setF({ ...f, date: e.target.value })} />
      <select value={f.shift} onChange={e => setF({ ...f, shift: e.target.value })}><option value="subah">Subah</option><option value="shaam">Shaam</option></select></div>
    <div className="row"><input type="number" placeholder="Litre" value={f.litre} onChange={e => setF({ ...f, litre: e.target.value })} />
      <input type="number" placeholder={'Rate ' + rate} value={f.rate} onChange={e => setF({ ...f, rate: e.target.value })} /></div>
    <button className="go" onClick={save}>Doodh likho</button>
    <div className="tot">Aaj: {rows.reduce((t, x) => t + x.litre, 0)} L · {rs(rows.reduce((t, x) => t + x.litre * x.rate, 0))}</div>
    {rows.map(x => <div className="item" key={x._id}><span>{nameOf(cs, x.customer)}<small>{x.shift} · {x.litre} L × {x.rate}</small></span><span>{rs(x.litre * x.rate)} <button className="x" onClick={() => del(x._id)}>✕</button></span></div>)}
  </div>;
}

function Sales({ cs, ps }) {
  const [f, setF] = useState({ customer: '', product: '', qty: '', price: '', date: today() }), [rows, setRows] = useState([]);
  const get = async () => setRows(await api('/sales?date=' + f.date));
  useEffect(() => { get(); }, [f.date]);
  const pick = n => { const p = ps.find(x => x.name === n); setF({ ...f, product: n, price: p ? p.price : '' }); };
  const save = async () => { if (!f.customer || !f.product || !f.qty) return; await api('/sales', 'POST', f); setF({ ...f, qty: '' }); get(); };
  const del = async id => { await api('/sales/' + id, 'DELETE'); get(); };
  return <div>
    <CustSel cs={cs} v={f.customer} on={v => setF({ ...f, customer: v })} />
    <select value={f.product} onChange={e => pick(e.target.value)}><option value="">Saaman chuno</option>{ps.map(p => <option key={p._id} value={p.name}>{p.name} ({rs(p.price)}/{p.unit})</option>)}</select>
    <div className="row"><input type="number" placeholder="Matra" value={f.qty} onChange={e => setF({ ...f, qty: e.target.value })} />
      <input type="number" placeholder="Price" value={f.price} onChange={e => setF({ ...f, price: e.target.value })} /></div>
    <div className="tot">Total: {rs(f.qty * f.price)}</div>
    <button className="go" onClick={save}>Saaman likho</button>
    {rows.map(x => <div className="item" key={x._id}><span>{nameOf(cs, x.customer)}<small>{x.product} · {x.qty} × {x.price}</small></span><span>{rs(x.qty * x.price)} <button className="x" onClick={() => del(x._id)}>✕</button></span></div>)}
  </div>;
}

function Pay({ cs }) {
  const [f, setF] = useState({ customer: '', amount: '', mode: 'cash', date: today() }), [rows, setRows] = useState([]);
  const get = async () => setRows(await api('/payments?date=' + f.date));
  useEffect(() => { get(); }, [f.date]);
  const save = async () => { if (!f.customer || !f.amount) return; await api('/payments', 'POST', f); setF({ ...f, amount: '' }); get(); };
  const del = async id => { await api('/payments/' + id, 'DELETE'); get(); };
  return <div>
    <CustSel cs={cs} v={f.customer} on={v => setF({ ...f, customer: v })} />
    <div className="row"><input type="number" placeholder="Rakam" value={f.amount} onChange={e => setF({ ...f, amount: e.target.value })} />
      <select value={f.mode} onChange={e => setF({ ...f, mode: e.target.value })}><option value="cash">Cash</option><option value="upi">UPI</option></select></div>
    <input type="date" value={f.date} onChange={e => setF({ ...f, date: e.target.value })} />
    <button className="go" onClick={save}>Jama karo</button>
    <div className="tot">Aaj jama: {rs(rows.reduce((t, x) => t + x.amount, 0))}</div>
    {rows.map(x => <div className="item" key={x._id}><span>{nameOf(cs, x.customer)}<small>{x.mode}</small></span><span>{rs(x.amount)} <button className="x" onClick={() => del(x._id)}>✕</button></span></div>)}
  </div>;
}

function Ledger({ cs }) {
  const [id, setId] = useState(''), [m, setM] = useState(today().slice(0, 7)), [d, setD] = useState(null);
  useEffect(() => { id ? api(`/ledger/${id}?month=${m}`).then(setD) : setD(null); }, [id, m]);
  return <div>
    <CustSel cs={cs} v={id} on={setId} />
    <input type="month" value={m} onChange={e => setM(e.target.value)} />
    {d && <>
      <div className="item"><span>Pichla baki</span><span>{rs(d.opening)}</span></div>
      <div className="item"><span>Doodh ({d.litres} L)</span><span>{rs(d.milkTotal)}</span></div>
      <div className="item"><span>Saaman</span><span>{rs(d.saleTotal)}</span></div>
      <div className="item"><span>Jama</span><span>− {rs(d.payTotal)}</span></div>
      <div className={'tot ' + (d.balance > 0 ? 'due' : '')}>Baki: {rs(d.balance)}</div>
      <h3>Doodh</h3>{d.milk.map(x => <div className="item" key={x._id}><span>{x.date} {x.shift}</span><span>{x.litre} L · {rs(x.litre * x.rate)}</span></div>)}
      <h3>Saaman</h3>{d.sales.map(x => <div className="item" key={x._id}><span>{x.date} {x.product}</span><span>{x.qty} × {x.price}</span></div>)}
      <h3>Jama</h3>{d.payments.map(x => <div className="item" key={x._id}><span>{x.date} {x.mode}</span><span>{rs(x.amount)}</span></div>)}
    </>}
  </div>;
}

function Settings({ ps, rate, load }) {
  const [r, setR] = useState(rate), [p, setP] = useState({ name: '', price: '', unit: 'kg' });
  useEffect(() => setR(rate), [rate]);
  const saveRate = async () => { await api('/settings', 'PUT', { milkRate: r }); load(); };
  const add = async () => { if (!p.name) return; await api('/products', 'POST', p); setP({ name: '', price: '', unit: 'kg' }); load(); };
  const upd = async (x, price) => { await api('/products/' + x._id, 'PUT', { price }); load(); };
  const del = async x => { await api('/products/' + x._id, 'DELETE'); load(); };
  return <div>
    <h3>Doodh ka rate (per litre)</h3>
    <div className="row"><input type="number" value={r} onChange={e => setR(e.target.value)} /><button className="go" onClick={saveRate}>Save</button></div>
    <h3>Saaman (Ghee, Pashuahar, Tel...)</h3>
    <input placeholder="Naam" value={p.name} onChange={e => setP({ ...p, name: e.target.value })} />
    <div className="row"><input type="number" placeholder="Price" value={p.price} onChange={e => setP({ ...p, price: e.target.value })} />
      <input placeholder="Unit (kg/L/bori)" value={p.unit} onChange={e => setP({ ...p, unit: e.target.value })} /></div>
    <button className="go" onClick={add}>Saaman jodo</button>
    {ps.map(x => <div className="item" key={x._id}><span>{x.name}<small>per {x.unit}</small></span>
      <span><input style={{ width: 90 }} type="number" defaultValue={x.price} onBlur={e => upd(x, e.target.value)} /> <button className="x" onClick={() => del(x)}>✕</button></span></div>)}
  </div>;
}

export default function App() {
  const [auth, setAuth] = useState(!!localStorage.token), [tab, setTab] = useState(0);
  const [cs, setCs] = useState([]), [ps, setPs] = useState([]), [rate, setRate] = useState(0);
  const load = async () => { setCs(await api('/customers')); setPs(await api('/products')); setRate((await api('/settings')).milkRate || 0); };
  useEffect(() => { auth && load(); }, [auth]);
  if (!auth) return <Login ok={() => setAuth(true)} />;
  const p = { cs, ps, rate, load };
  return <div className="app">
    <nav>{TABS.map((t, i) => <button key={t} className={i === tab ? 'on' : ''} onClick={() => setTab(i)}>{t}</button>)}</nav>
    {[<Customers {...p} />, <Milk {...p} />, <Sales {...p} />, <Pay {...p} />, <Ledger {...p} />, <Settings {...p} />][tab]}
  </div>;
}
