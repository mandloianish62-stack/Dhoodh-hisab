# Doodh Khata (MERN)

## Server
cd server && cp .env.example .env   (MONGO_URI, ADMIN_USER, ADMIN_PASS, JWT_SECRET badlo)
npm install && npm start            (port 5000)

## Client
cd client && npm install && npm run dev
Online server ho to client/.env me: VITE_API=https://aapka-server-url
