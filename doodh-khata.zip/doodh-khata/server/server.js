require('dotenv').config();
const express = require('express'), mongoose = require('mongoose'), cors = require('cors'), jwt = require('jsonwebtoken');
const app = express(); app.use(cors(), express.json());

const S = mongoose.Schema, cust = { type: S.Types.ObjectId, ref: 'Customer', required: true };
const M = (n, s) => mongoose.model(n, new S(s, { timestamps: true }));
const Customer = M('Customer', { name: { type: String, required: true }, phone: String, address: String });
const Product = M('Product', { name: { type: String, required: true }, price: Number, unit: { type: String, default: 'kg' } });
const Milk = M('Milk', { customer: cust, date: String, shift: { type: String, enum: ['subah', 'shaam'] }, litre: Number, rate: Number });
const Sale = M('Sale', { customer: cust, product: String, qty: Number, price: Number, date: String });
const Payment = M('Payment', { customer: cust, amount: Number, mode: { type: String, default: 'cash' }, date: String });
const Setting = M('Setting', { key: String, value: S.Types.Mixed });

app.post('/api/login', (q, s) => {
  const { user, pass } = q.body;
  if (user === process.env.ADMIN_USER && pass === process.env.ADMIN_PASS)
    return s.json({ token: jwt.sign({ user }, process.env.JWT_SECRET, { expiresIn: '90d' }) });
  s.status(400).json({ error: 'Galat user ya password' });
});

const auth = (q, s, n) => {
  try { jwt.verify((q.headers.authorization || '').slice(7), process.env.JWT_SECRET); n(); }
  catch { s.status(401).json({ error: 'login karo' }); }
};

const crud = (path, Model) => {
  const r = express.Router();
  r.get('/', async (q, s) => {
    const f = { ...q.query };
    if (f.month) { f.date = new RegExp('^' + f.month); delete f.month; }
    s.json(await Model.find(f).sort({ date: -1, createdAt: -1 }));
  });
  r.post('/', async (q, s) => s.json(await Model.create(q.body)));
  r.put('/:id', async (q, s) => s.json(await Model.findByIdAndUpdate(q.params.id, q.body, { new: true })));
  r.delete('/:id', async (q, s) => { await Model.findByIdAndDelete(q.params.id); s.json({ ok: 1 }); });
  app.use('/api/' + path, auth, r);
};
crud('customers', Customer); crud('products', Product); crud('milk', Milk); crud('sales', Sale); crud('payments', Payment);

app.get('/api/settings', auth, async (q, s) => {
  const r = await Setting.findOne({ key: 'milkRate' }); s.json({ milkRate: r ? r.value : 0 });
});
app.put('/api/settings', auth, async (q, s) => {
  await Setting.findOneAndUpdate({ key: 'milkRate' }, { value: Number(q.body.milkRate) }, { upsert: true }); s.json({ ok: 1 });
});

// Customer ka mahine ka hisab: pichla baki + doodh + saaman - jama = baki
app.get('/api/ledger/:id', auth, async (q, s) => {
  const { id } = q.params, m = q.query.month;
  const [milk, sales, pays] = await Promise.all([Milk.find({ customer: id }), Sale.find({ customer: id }), Payment.find({ customer: id })]);
  const sum = (a, f) => a.reduce((t, x) => t + f(x), 0);
  const mv = x => x.litre * x.rate, sv = x => x.qty * x.price, pv = x => x.amount;
  const before = a => a.filter(x => x.date < m), within = a => a.filter(x => x.date.startsWith(m));
  const opening = sum(before(milk), mv) + sum(before(sales), sv) - sum(before(pays), pv);
  const mi = within(milk), sa = within(sales), pa = within(pays);
  const milkTotal = sum(mi, mv), saleTotal = sum(sa, sv), payTotal = sum(pa, pv);
  s.json({ opening, milkTotal, saleTotal, payTotal, litres: sum(mi, x => x.litre), balance: opening + milkTotal + saleTotal - payTotal, milk: mi, sales: sa, payments: pa });
});

mongoose.connect(process.env.MONGO_URI).then(() => app.listen(process.env.PORT || 5000, () => console.log('Server chalu')));
